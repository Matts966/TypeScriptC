.. cmake-module:: ../../Modules/CMakeBackwardCompatibilityCXX.cmake
